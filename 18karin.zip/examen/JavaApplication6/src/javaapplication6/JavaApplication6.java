/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

/**
 *
 * @author estudiante
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String scion = ("HOLA MUNDO"); 
        String honda  = ("ESTE NECESITA DE TI");
        String acura = ("29/10/2017"); 
        String toyota = ("DEBEMOS DE CUIDAR EL MUNDO");
        String mazda = (" CUIDEMOS NUESTRO MEDIO AMBIENTE"); 
        System.out.println(scion + honda + acura + toyota + mazda ); 
        
        
    }
    
}
